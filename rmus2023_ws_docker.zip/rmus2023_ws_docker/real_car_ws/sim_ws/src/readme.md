## 激光雷达的坑：博导2XXXXX那里，不是115200，launch也要改，好像不差5v也可以炮
运行工作空间的时候要source devel/setup.bash

sim2@sim2:~$ cd sim_ws/
sim2@sim2:~/sim_ws$ source devel/setup.bash 
sim2@sim2:~/sim_ws$ roslaunch rmus_solution start_game.launch 
打开夹子：（tab】】）rostopic pub /arm_gripperd

rosrun rmus_solution test.py 

