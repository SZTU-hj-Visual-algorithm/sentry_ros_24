export http_proxy="http://192.168.46.42:7890"
export https_proxy="https://192.168.46.42:7890"