#include "decision_node.hpp"
#include "utils.hpp"

template <typename Tp, size_t Nm>
static std::array<Tp, Nm> retrive_array_param(const ros::NodeHandle &nh,
                                              const std::string &param) {
	std::vector<Tp> values;
	if (!nh.getParam(param, values)) {
		throw std::runtime_error("Parameter " + param + " is not set!");
	}
	if (values.size() != Nm) {
		throw std::runtime_error("Size of parameter " + param + " is not " +
		                         std::to_string(Nm));
	}
	std::array<Tp, Nm> array;
	for (size_t i = 0; i < Nm; i++) {
		array[i] = values[i];
	}
	return array;
}

static geometry_msgs::Pose retrive_pose_param(const ros::NodeHandle &nh,
                                              const std::string &param) {
	auto values = retrive_array_param<double, 3>(nh, param);
	double x = values[0];
	double y = values[1];
	double yaw = values[2];
	geometry_msgs::Pose pose;
	pose.position.x = x;
	pose.position.y = y;
	pose.position.z = 0;
	pose.orientation = quaternionMsgFromYaw(yaw);
	return pose;
}

DecisionNode::DecisionNode()
    : move_action("move_base", true), arm_action("grasp_place", true),
      tf_listener(tf_buffer), state(State::INIT) {
	
	for (auto& kf : tag_kf) {
        kf = KalmanFilter2D(Eigen::Vector2d(0.0, 0.0), 0.01, 0.02);
    }

	markers_sub = nh.subscribe<apriltag_msgs::ApriltagMarkerArray>(
	    "markers", 1,
	    std::bind(&DecisionNode::on_markers_detected, this,
	              std::placeholders::_1));

	markerArrayPub = nh.advertise<visualization_msgs::MarkerArray>("marker_array_topic", 10);

	//move_base_cancel_pub_ = nh.advertise<actionlib_msgs::GoalID>("/move_base/cancel",10);

	tf_listener_ = std::make_shared<tf::TransformListener>();

	ros::NodeHandle nh_private("~");
	exchange_detection_location =
	    retrive_pose_param(nh_private, "locations/exchange_detection");
	ore_locations[0] = retrive_pose_param(nh_private, "locations/ore_1_1");
	ore_locations[3] = retrive_pose_param(nh_private, "locations/ore_1_2");
	ore_locations[6] = retrive_pose_param(nh_private, "locations/ore_1_3");

	ore_locations[1] = retrive_pose_param(nh_private, "locations/ore_2_1");
	ore_locations[4] = retrive_pose_param(nh_private, "locations/ore_2_2");
	ore_locations[7] = retrive_pose_param(nh_private, "locations/ore_2_3");

	ore_locations[2] = retrive_pose_param(nh_private, "locations/ore_3_1");
	ore_locations[5] = retrive_pose_param(nh_private, "locations/ore_3_2");
	ore_locations[8] = retrive_pose_param(nh_private, "locations/ore_3_3");

	area_locations[0] =  retrive_pose_param(nh_private, "locations/area_1");
	area_locations[1] =  retrive_pose_param(nh_private, "locations/area_2");
	area_locations[2] =  retrive_pose_param(nh_private, "locations/area_3");
	
	exchange_locations[0] =
	    retrive_pose_param(nh_private, "locations/exchange_B");
	exchange_locations[1] =
	    retrive_pose_param(nh_private, "locations/exchange_O");
	exchange_locations[2] =
	    retrive_pose_param(nh_private, "locations/exchange_X");
	first_ore_preference =
	    retrive_array_param<int, 3>(nh_private, "first_ore_preference");
	final_pos =
		retrive_pose_param(nh_private, "locations/final_pos");

	for (int i = 0; i < 12; ++i)
    {
        double x = 0.0;
        double y = 0.0;
        double z = 0.0;
        publishMarker(x, y, z,1,0,0);
    }


	for (int &ore_id : first_ore_preference) {
		ore_id--; // convert 1~5 to 0~4
	}

	// ros::start();
	// ros::AsyncSpinner spinner(0); // 使用2个线程
  	// spinner.start();

	move_action.waitForServer();
	arm_action.waitForServer();
}

void DecisionNode::start() {
	std::fill(task_finished.begin(), task_finished.end(), false);
	to_detect_exchange();
}



int DecisionNode::publishMarker(double x, double y, double z,double r ,double g ,double b)
{
    // Create and configure Marker
    visualization_msgs::Marker marker;
    marker.header.frame_id = "map";  // Adjust the frame_id according to your needs
    marker.header.stamp = ros::Time::now();
    marker.ns = "marker";
    marker.id = markers.markers.size();  // Unique ID for each marker
    marker.type = visualization_msgs::Marker::SPHERE;
    marker.action = visualization_msgs::Marker::ADD;
    marker.pose.position.x = x;
    marker.pose.position.y = y;
    marker.pose.position.z = z;
    marker.pose.orientation.x = 0.0;
    marker.pose.orientation.y = 0.0;
    marker.pose.orientation.z = 0.0;
    marker.pose.orientation.w = 1.0;
    marker.scale.x = 0.05;
    marker.scale.y = 0.05;
    marker.scale.z = 0.05;
    marker.color.r = r;
    marker.color.g = g;
    marker.color.b = b;
    marker.color.a = 1.0;

    // Add marker to MarkerArray
    markers.markers.push_back(marker);

    // Publish MarkerArray
    markerArrayPub.publish(markers);

    // Return the ID of the newly published marker
    return marker.id;
}

void DecisionNode::updateMarker(int id, double newX, double newY, double newZ,double newR,double newG,double newB)
{
    // Update marker with specified ID
    for (auto& marker : markers.markers)
    {
        if (marker.id == id)
        {
            marker.pose.position.x = newX;
            marker.pose.position.y = newY;
            marker.pose.position.z = newZ;
			marker.color.r = newR;
			marker.color.g = newG;
			marker.color.b = newB;
            break;
        }
    }

    // Publish updated MarkerArray
    markerArrayPub.publish(markers);
}


void DecisionNode::deleteMarker(int id)
{
    // Remove marker with specified ID
    for (auto it = markers.markers.begin(); it != markers.markers.end(); ++it)
    {
        if (it->id == id)
        {
            it = markers.markers.erase(it);
            break;
        }
    }

    // Publish updated MarkerArray
    markerArrayPub.publish(markers);
}

bool DecisionNode::isDuplicate(const std::vector<int>& arr, int value) {
    for (int num : arr) {
        if (num == value) {
            return true;
        }
    }
    return false;
}

double DecisionNode::GetEuclideanDistance(const geometry_msgs::Pose & pose_1,
                            const geometry_msgs::Pose & pose_2){
  return hypot(pose_1.position.x-pose_2.position.x,
               pose_1.position.y-pose_2.position.y);
}

bool DecisionNode::TransformPose(const std::shared_ptr<tf::TransformListener>& tf_listener,
                   const std::string& target_frame,
                   const geometry_msgs::PoseStamped& input_pose,
                   geometry_msgs::PoseStamped& output_pose,
                   const ros::Time& target_time ,
                   const ros::Duration& timeout ){

                  
  if (target_frame == input_pose.header.frame_id){
    output_pose = input_pose;
    return true;
  }
     
  tf::Stamped<tf::Pose> input_pose_tf, output_pose_tf;
  tf::poseStampedMsgToTF(input_pose,input_pose_tf);

  try{
    tf_listener->waitForTransform( target_frame, target_time, 
                                   input_pose.header.frame_id, input_pose.header.stamp, 
                                   input_pose.header.frame_id, timeout );
    tf_listener->transformPose( target_frame, input_pose_tf, output_pose_tf);
  }
  catch (tf::TransformException &ex) {
    ROS_ERROR("Failed to transform pose: %s", ex.what());
    return false;
  }

  tf::poseStampedTFToMsg(output_pose_tf, output_pose);
  return true;
}


void DecisionNode::on_markers_detected(
    const apriltag_msgs::ApriltagMarkerArray::ConstPtr &markers) {

	if (state == State::TAG_OBVERSE)
	{
		for(int i =0 ;i<6;i++)
		{
			if(tag_map[i]==current_area)
			{
				ROS_INFO("tag:[%d] in area[%d]",i+1,current_area);
			}
		}
		return;
	}

	for (const auto &marker : markers->markers) {
		if (marker.id >= 6) {
			// B, O, X
			continue;
		}
		geometry_msgs::PoseStamped pose;
		pose.header = marker.header;
		pose.pose = marker.pose;
		if (pose.header.frame_id != "camera_color_optical_frame") {
			ROS_WARN_STREAM("Marker is in "
			                << pose.header.frame_id
			                << ", not camera_color_optical_frame!");
			continue;
		}

		 geometry_msgs::PoseStamped pose_in_map;
		 pose_in_map.header.frame_id = "map";
		
		TransformPose(tf_listener_, "map", pose, pose_in_map,ros::Time::now(),ros::Duration(0.5));


		if (pose_in_map.pose.position.z < -0.040) {
			
			//ROS_INFO("TAG:%d location: (%d, %d, 0)", marker.id+1, pose_in_map.pose.position.x,pose_in_map.pose.position.y);

			Eigen::Vector2d tag_ms(pose_in_map.pose.position.x,pose_in_map.pose.position.y);

			tag_kf[marker.id].Predict();
			tag_kf[marker.id].Update(tag_ms);

			pose_in_map.pose.position.x = tag_kf[marker.id].GetState()(0);
			pose_in_map.pose.position.y = tag_kf[marker.id].GetState()(1);

			tag_locations[marker.id] = pose_in_map.pose ; 

			geometry_msgs::Pose pos_loc = compute_goal(pose,0.3);

			grasp_locations[marker.id] = pos_loc;


			std::array<double, 3> distance_ore;
			for(int i= 0 ;i<3;i++){
				distance_ore[i] = GetEuclideanDistance(pose_in_map.pose,area_locations[i]);
			}
    	
			int minIndex = 0; // 假设初始最小索引为0
			 for (size_t i = 1; i < 3; ++i) {
       				 if (distance_ore[i] < distance_ore[minIndex]) {
          		  // 如果找到更小的元素，更新最小索引
          		  minIndex = i;
      			  }
   			 }
			
			if (tag_flag[marker.id]==0)
			{
				tag_map[marker.id] = minIndex;
				updateMarker(marker.id,pose_in_map.pose.position.x,pose_in_map.pose.position.y,0,0,1,0);
				updateMarker(marker.id+6,pos_loc.position.x,pos_loc.position.y,0,1,1,0);
			}
			
			//ROS_INFO("tag[%d] in %d", marker_ids , minIndex);
			
		    
		}
			
		}
		

	
	if (state != State::DETECT_EXCHANGE) {

		return;
	}


	using ExchangeTag = std::tuple<int, geometry_msgs::PoseStamped>;
	std::vector<ExchangeTag> exchange_tags;
	for (const auto &marker : markers->markers) {
		if (marker.id >= 6) {
			// B, O, X
			continue;
		}
		geometry_msgs::PoseStamped pose;
		pose.header = marker.header;
		pose.pose = marker.pose;
		if (pose.header.frame_id != "camera_color_optical_frame") {
			ROS_WARN_STREAM("Marker is in "
			                << pose.header.frame_id
			                << ", not camera_color_optical_frame!");
			continue;
		}
		geometry_msgs::PoseStamped pose_in_base_link;
		try {
			pose_in_base_link = tf_buffer.transform(pose, "base_link");
		} catch (tf2::TransformException &ex) {
			ROS_WARN_STREAM(
			    "Can't transform exchange marker pose: " << ex.what());
			continue;
		}
		if (pose_in_base_link.pose.position.z < 0.200) {
			continue;
		}
		exchange_tags.push_back({marker.id, pose});
	}

	if (exchange_tags.size() < 3) {
		return;
	} else if (exchange_tags.size() > 3) {
		ROS_WARN_STREAM("Detected " << exchange_tags.size()
		                            << " exchange tags!");
		return;
	}

	std::sort(exchange_tags.begin(), exchange_tags.end(),
	          [](const ExchangeTag &a, const ExchangeTag &b) {
		          const auto &pose_a = std::get<1>(a);
		          const auto &pose_b = std::get<1>(b);
		          return pose_a.pose.position.x < pose_b.pose.position.x;
	          });

	for (int i = 0; i < 3; i++) {
		task_ores[i] = std::get<0>(exchange_tags[i]);
	}

	ROS_INFO("Ores: %d, %d, %d", task_ores[0] + 1, task_ores[1] + 1,    task_ores[2] + 1);
	int j=0;
	int c =0;
	for(int i=0;i<6;i++){
		for(c=0;c<3;c++){
			if (task_ores[c]==i)
			break;
		}
		if(c==3)
		{
			task_ores2[j] = i;
			j++;
		}
	}
	ROS_INFO("Ores2: %d, %d, %d", task_ores2[0] + 1, task_ores2[1] + 1,    task_ores2[2] + 1);

	to_nav_ore(current_loc);
	
}

void DecisionNode::to_detect_exchange() {
	state = State::DETECT_EXCHANGE;
	ROS_INFO("DETECT_EXCHANGE");

	navigate_to(exchange_detection_location, 5,0.01,[this](bool success) {});
}

void DecisionNode::to_nav_ore(int task_idx) { 
	state = State::NAV_ORE; 
	ROS_INFO("NAV_ORE");

	ROS_INFO_STREAM("Going to pos " << (task_idx));

	navigate_to(ore_locations[task_idx],15,0.01, [this](bool success) { to_obverse_ore(); });
	

}

int DecisionNode::findDataInArray(const std::vector<int>& myArray, int target) {
    for (size_t i = 0; i < myArray.size(); ++i) {
        if (myArray[i] == target) {
            return i;
        }
    }

    return -1;
}

geometry_msgs::Pose 
DecisionNode::compute_goal(const geometry_msgs::PoseStamped &target,
                         double seperation) {
	geometry_msgs::PoseStamped target_relative =
	    tf_buffer.transform(target, "base_link", ros::Duration(0.5));
	double target_x = target_relative.pose.position.x;
	double target_y = target_relative.pose.position.y;
	double target_yaw = get_yaw(target_relative.pose.orientation);
	double goal_x = target_x + std::cos(target_yaw) * seperation;
	double goal_y = target_y + std::sin(target_yaw) * seperation;
	double goal_yaw = normalize_angle(target_yaw + M_PI);
	geometry_msgs::PoseStamped tag_in_map;
	geometry_msgs::PoseStamped tag_in_base;
	tag_in_base.header.frame_id = "base_link";
	tag_in_map.header.frame_id = "map";
	tag_in_base.pose.position.x = goal_x;
	tag_in_base.pose.position.y = goal_y;
	tf2::Quaternion quaternion;
    quaternion.setRPY(0, 0, goal_yaw);
	tag_in_base.pose.orientation.x = quaternion.getX();
    tag_in_base.pose.orientation.y = quaternion.getY();
    tag_in_base.pose.orientation.z = quaternion.getZ();
    tag_in_base.pose.orientation.w = quaternion.getW();

	TransformPose(tf_listener_, "map", tag_in_base, tag_in_map,ros::Time::now(),ros::Duration(0.5));

	return tag_in_map.pose;
}

void DecisionNode::to_obverse_ore() {
	state = State::TAG_OBVERSE;
	ROS_INFO("TAG_OBVERSE");
	ros::Rate rate(10);
	int time_out = 0;
    while(current_ore==9)
	{
		rate.sleep();
		ROS_INFO("WAITING:TAG_OBVERSE");
		time_out+=1;
		auto next_task = choose_next_task();
		if (next_task.has_value()) {
			if (next_task == current_area)
			{
				break;
			}
			else
			{
				current_ore  = 9 ;
			}
		} 
		if(time_out>5)
		{
			ROS_INFO("HERE:IS NOTING");
			break;
		}
	}
	
	
	if(time_out<5 && current_ore!=9)
	{
		// navigate_to(grasp_locations[current_ore],5,0.01,[this](bool success) {});
		to_grasp_ore(current_ore);
	}
	else{
		auto next_loc = choose_next_loc();
		if (next_loc.has_value()) {
			to_nav_ore(*next_loc);
			}
		else {
			navigate_to(final_pos,15,0.01,
	    	[this](bool success) { to_end();});	    
			}

		
		ROS_INFO("NOT:TAG_OBVERSE IS NOTING");
		
	}
}

void DecisionNode::to_grasp_ore(int ore) {

	state = State::GRASP_ORE;
	if (ore > 5 )
	{
	ROS_INFO("Grasping ORE NUM ERROR ");
	return;
	}
	//int ore = task_ores[index];
	//current_ore = ore ; 
	ROS_INFO_STREAM("Grasping ore " << (ore + 1));
	
	arm_controller_srvs::GraspPlaceGoal goal;
	goal.action_type = arm_controller_srvs::GraspPlaceGoal::ACTION_GRASP_ORE;
	goal.marker_id = ore;
	arm_action.sendGoal(
	    goal,
	    [this](const actionlib::SimpleClientGoalState &state,
	           const arm_controller_srvs::GraspPlaceResult::ConstPtr &result) {
		    if (state == actionlib::SimpleClientGoalState::SUCCEEDED) {
			    ROS_INFO("Grasp succeeded");
				
			    to_nav_exchange();

		    } else {
			    ROS_ERROR_STREAM("Grasp failed, will retry. "
			                     << state.toString() << ": "
			                     << state.getText());
				current_loc+=3;	
				if(current_loc>8)
				{
					current_loc = current_area;
				}	 
				to_nav_ore(current_loc);
		    }
	    });


}

void DecisionNode::to_nav_exchange() {
	state = State::NAV_EXCHANGE;
	int index =0;
	for(; index<3;index++ )
		{
			if (task_ores[index]==current_ore)
			{
				current_place = index;
				break;
			}
			if (task_ores2[index]==current_ore)
			{	
				current_place = index;
				index =1;
				break;
			}
		}
	
	ROS_INFO_STREAM("Navigating to exchange #" << index);
	navigate_to(exchange_locations[index],15,0.01,
	            [this](bool success) { to_place_ore(current_place); });
}

void DecisionNode::to_place_ore(int place) {
	state = State::PLACE_ORE;

	ROS_INFO_STREAM("Place ore to exchange #" << place);
	int exchanage_marker_id = 6 + place;
	if(flag==0)
	{
		task_finished[place]= true;
	}
	else
	{
		task_finished[place+3] = true;
		//exchanage_marker_id = task_ores[1];

		//exchanage_marker_id = 7;
		if (current_count==3)
		{
			exchanage_marker_id = 6;
		}
		else if(current_count==4)
		{
			exchanage_marker_id = 8;
		}
		else if(current_count==5)
		{
			exchanage_marker_id = 7;
		}
	
		
	}
	
	arm_controller_srvs::GraspPlaceGoal goal;
	if(flag==0)
	{
		goal.action_type = arm_controller_srvs::GraspPlaceGoal::ACTION_PLACE_ORE;
	}
	else
	{
		goal.action_type = arm_controller_srvs::GraspPlaceGoal::ACTION_PLACE_SEC;
	}
	goal.marker_id = exchanage_marker_id;
	arm_action.sendGoal(
	    goal,
	    [this](const actionlib::SimpleClientGoalState &state,
	           const arm_controller_srvs::GraspPlaceResult::ConstPtr &result) {
		    if (state == actionlib::SimpleClientGoalState::SUCCEEDED) {
			    ROS_INFO("Place succeeded");
					tag_map[current_ore] = 4;
					tag_flag[current_ore] = 1;
					current_ore = 9;
					ROS_INFO("Task_Finish:%d,%d,%d,%d,%d,%d",task_finished[0],task_finished[1],task_finished[2],task_finished[3],task_finished[4],task_finished[5]);
					current_count++;
					ROS_INFO("Task_Count：%d",current_count);
			    auto next_task = choose_next_task();
			    if (next_task.has_value()) {
				    to_nav_ore(*next_task);
			    } else {
					auto next_loc = choose_next_loc();
					if(next_loc.has_value()){
						to_nav_ore(*next_loc);
					}
					else{
						navigate_to(final_pos,15,0.01,
	            		[this](bool success) { to_end();});
					}
					
				    
			    }

		    } else {
			    ROS_ERROR_STREAM("Place failed, will retry. "
			                     << state.toString() << ": "
			                     << state.getText());
			    to_nav_exchange();
		    }
	    });
}

void DecisionNode::to_end() {
	state = State::DONE;
	
	for (int i =0;i<6;i++)
	{
		ROS_INFO("TAG:%d location: (%f, %f)", i+1, tag_locations[i].position.x,tag_locations[i].position.y);
	}


}



std::optional<int> DecisionNode::choose_next_task() {

	if(task_finished[0]==true&&task_finished[1]==true&&task_finished[2]==true)
	{
		flag=1;
	}

	if(flag==0){
		for (int i = 0; i < 6; i++) {
			if( tag_map[i]!=4)
			{
				for(int j = 0;j <3;j++ ) {
					if (i == task_ores[j]){
					ROS_INFO("Find1 %d in pos[%d]",i+1,tag_map[i]);
					current_ore = i;
					current_loc = tag_map[i];
					current_area = tag_map[i];
					return tag_map[i];
					}
					
				}
			}
		}
			
	}
	else{
		for (int i = 0; i < 6; i++) {
			if( tag_map[i]!=4)
			{
				for(int j = 0;j <3;j++ ) {
					if (i == task_ores2[j])
					{
					ROS_INFO("Find2 %d in pos[%d]",task_ores2[j]+1,tag_map[i]);
					current_ore = task_ores2[j];
					current_loc = tag_map[i];
					current_area = tag_map[i];
					return tag_map[i];
					}
					
				}
			}
			}
			
	}
	


	return std::nullopt;
}

std::optional<int> DecisionNode::choose_next_loc(){
	for (int i = 0; i < 6; i++) {
		if (task_finished[i]==false) {
			current_loc+=1;
			
			if (current_loc>8)
			{
				current_loc=0;
			}
			//ROS_INFO("Current:area:[%d]",current_area);
			ROS_INFO("Current:loc:[%d]",current_loc);
			return current_loc;
		}
	}

	return std::nullopt;

}

void DecisionNode::navigate_to(const geometry_msgs::Pose &pose, double timeout, double distance,std::function<void(bool)> cb) {
	move_base_msgs::MoveBaseGoal goal;
	goal.target_pose.header.stamp = ros::Time::now();
	goal.target_pose.header.frame_id = "map";
	goal.target_pose.pose = pose;
	ROS_INFO_STREAM("Navigating to x=" << pose.position.x
	                                   << ", y=" << pose.position.y << ", yaw="
	                                   << get_yaw(pose.orientation));

	ros::Time start_time = ros::Time::now();
	geometry_msgs::PoseStamped robot_in_map;
	geometry_msgs::PoseStamped robot_in_base;
	robot_in_base.header.frame_id = "base_link";
	robot_in_map.header.frame_id = "map";
	robot_in_base.pose.position.x = 0;
	robot_in_base.pose.position.y = 0;


	ROS_INFO_STREAM("Navigating to x=" << pose.position.x
	                                   << ", y=" << pose.position.y << ", yaw="
	                                   << get_yaw(pose.orientation));
	move_action.sendGoal(
	    goal, [cb](const actionlib::SimpleClientGoalState &state,
	               const move_base_msgs::MoveBaseResult::ConstPtr &result) {
		    if (state == actionlib::SimpleClientGoalState::SUCCEEDED) {
			    ROS_INFO("Navigation succeeded");
			    cb(true);
		    } else {
			    ROS_ERROR_STREAM("Navigation failed. " << state.toString()
			                                           << ": "
			                                           << state.getText());
			    cb(false);
		    }
	    });
	// move_action.sendGoal(goal); 
	// //ros::Rate rate(10);

	// while (!move_action.waitForResult(ros::Duration(0.1)))
    // {	
		
    //     // 检查是否超过超时时间
    //     if ((ros::Time::now() - start_time).toSec() > timeout)
    //     {
    //         ROS_WARN("Navigation Timeout");
    //         move_action.cancelGoal(); // 取消目标
	// 		cb(true);
    //         break;
    //     }
	// 	// TransformPose(tf_listener_, "map", robot_in_base, robot_in_map,ros::Time::now(),ros::Duration(0.1));
	// 	// if(GetEuclideanDistance(robot_in_map.pose,pose)<distance)
	// 	// {
	// 	// 	ROS_WARN("Navigation in range");
    //     //     move_action.cancelGoal(); // 取消目标
	// 	// 	cb(true);
    //     //     break;
	// 	// }

	// 	ros::spinOnce();
		
    // }

	//  if (move_action.getState() == actionlib::SimpleClientGoalState::SUCCEEDED)
    // {
    //     ROS_INFO("Navigation succeeded!");
    //     // 计算执行时间
    //     double execution_time = (ros::Time::now() - start_time).toSec();
    //     ROS_INFO("time: %.2f s", execution_time);
	// 	cb(true);
    // }
    // else
    // {
    //     ROS_ERROR("Navigation failed.!");
	// 	cb(true);
    // }
		
		
}
