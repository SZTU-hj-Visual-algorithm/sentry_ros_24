#pragma once

#include <actionlib/client/simple_action_client.h>
#include <apriltag_msgs/ApriltagMarkerArray.h>
#include <arm_controller_srvs/GraspPlaceAction.h>
#include <move_base_msgs/MoveBaseAction.h>
#include <ros/ros.h>
#include <tf2_ros/transform_listener.h>
#include <visualization_msgs/MarkerArray.h>
#include <tf/transform_listener.h>
#include <algorithm>

#include <Eigen/Dense>

class KalmanFilter2D {
public:
    KalmanFilter2D() {}

    KalmanFilter2D(const Eigen::Vector2d& initial_state, double process_variance, double measurement_variance)
        : state_(initial_state), process_variance_(process_variance), measurement_variance_(measurement_variance) {
        state_covariance_ = Eigen::Matrix2d::Identity();
    }

    void Predict() {
        state_prediction_ = state_;
        state_covariance_prediction_ = state_covariance_ + process_variance_ * Eigen::Matrix2d::Identity();
    }

    void Update(const Eigen::Vector2d& measurement) {
        kalman_gain_ = state_covariance_prediction_ * (state_covariance_prediction_ + measurement_variance_ * Eigen::Matrix2d::Identity()).inverse();
        state_ = state_prediction_ + kalman_gain_ * (measurement - state_prediction_);
        state_covariance_ = (Eigen::Matrix2d::Identity() - kalman_gain_) * state_covariance_prediction_;
    }

    Eigen::Vector2d GetState() const {
        return state_;
    }

private:
    Eigen::Vector2d state_;
    double process_variance_;
    double measurement_variance_;

    Eigen::Matrix2d state_covariance_;
    Eigen::Vector2d state_prediction_;
    Eigen::Matrix2d state_covariance_prediction_;
    Eigen::Matrix2d kalman_gain_;
};



class DecisionNode {
  public:
	DecisionNode();

	void start();

  private:
	enum class State {
		INIT,
		DETECT_EXCHANGE,
		NAV_ORE,
		TAG_OBVERSE,
		GRASP_ORE,
		NAV_EXCHANGE,
		PLACE_ORE,
		DONE
	};


	ros::NodeHandle nh;
	actionlib::SimpleActionClient<move_base_msgs::MoveBaseAction> move_action;
	actionlib::SimpleActionClient<arm_controller_srvs::GraspPlaceAction>
	    arm_action;
	ros::Subscriber markers_sub;
	ros::Publisher markerArrayPub;
	ros::Publisher move_base_cancel_pub_;

	visualization_msgs::MarkerArray markers;
	tf2_ros::Buffer tf_buffer;
	tf2_ros::TransformListener tf_listener;

	std::shared_ptr<tf::TransformListener> tf_listener_;
	 tf::StampedTransform tag2map_transform_;
	
	std::array<KalmanFilter2D, 6> tag_kf;


	geometry_msgs::Pose exchange_detection_location;
	std::array<geometry_msgs::Pose, 9> ore_locations;
	std::array<geometry_msgs::Pose, 3> exchange_locations;
	std::array<geometry_msgs::Pose, 3> area_locations;
    geometry_msgs::Pose final_pos;

	std::array<geometry_msgs::Pose, 6> tag_locations;
	std::array<geometry_msgs::Pose, 6> grasp_locations;
	std::array<int,6> tag_map = {4,4,4,4,4,4};
	std::array<int,6> tag_flag = {0,0,0,0,0,0};
	std::array<int, 6> marker_ids;

	std::array<int, 3> first_ore_preference;
	std::optional<std::array<int, 3>> task_ores_override;

	State state;
	std::array<int, 3> task_ores;
	std::array<int, 3> task_ores2;
	std::array<bool, 6> task_finished ;

	int flag = 0;
	int current_ore = 9; //0,1,2,3,4,5 
	int current_loc = 0; //0,1,2,3,4,5,6,7,8
	int current_area = 0 ; // 0,1,2
	int current_place = 0 ;
	int current_count = 0 ; 

	

	void on_markers_detected(
	    const apriltag_msgs::ApriltagMarkerArray::ConstPtr &markers);
	void to_detect_exchange();
	bool isDuplicate(const std::vector<int>& arr, int value);
	int findDataInArray(const std::vector<int>& myArray, int target);
	void to_nav_ore(int task_idx);
	void to_grasp_ore(int ore);
	void to_nav_exchange();
	void to_place_ore(int place);
	void to_obverse_ore();
	void to_end();

	int publishMarker(double x, double y, double z,double r ,double g ,double b);
	void deleteMarker(int id);
	void updateMarker(int id, double newX, double newY, double newZ,double newR,double newG,double newB);
	std::optional<int> choose_next_task();

	std::optional<int> choose_next_loc();

	geometry_msgs::Pose 
	compute_goal(const geometry_msgs::PoseStamped &target,
                         double seperation) ;

	void navigate_to(const geometry_msgs::Pose &pose, double timeout, double distance,std::function<void(bool)> cb);

	double GetEuclideanDistance(const geometry_msgs::Pose & pose_1,
                            const geometry_msgs::Pose & pose_2);

	bool TransformPose(const std::shared_ptr<tf::TransformListener>& tf_listener,
                   const std::string& target_frame,
                   const geometry_msgs::PoseStamped& input_pose,
                   geometry_msgs::PoseStamped& output_pose,
                   const ros::Time& target_time = ros::Time::now(),
                   const ros::Duration& timeout = ros::Duration(0.5));
};
