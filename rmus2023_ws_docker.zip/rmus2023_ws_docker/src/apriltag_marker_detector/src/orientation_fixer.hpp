#pragma once

#include "detector.hpp"

namespace apriltag_marker_detector {

void fix_marker_orientation(TagDetection &marker);

}
