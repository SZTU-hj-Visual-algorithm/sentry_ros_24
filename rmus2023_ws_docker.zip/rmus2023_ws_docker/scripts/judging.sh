#!/bin/bash
docker exec -it ros-master /opt/ros/noetic/env.sh rostopic echo /judgement/markers_time
